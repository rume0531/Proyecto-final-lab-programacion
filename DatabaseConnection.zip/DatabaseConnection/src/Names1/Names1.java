package Names1;

import java.util.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Names1 {
    private String fname;
    private String minit;
    private String lname;
    private int jobId;
    private int jobLvl;
    private int pubId;
    private Date hireDate;

    // Constructor
    public Names1(String fname, String minit, String lname, int jobId, int jobLvl, int pubId, Date hireDate) {
        this.fname = fname;
        this.minit = minit;
        this.lname = lname;
        this.jobId = jobId;
        this.jobLvl = jobLvl;
        this.pubId = pubId;
        this.hireDate = hireDate;
    }

    // Getter y setter para fname
    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    // Getter y setter para minit
    public String getMinit() {
        return minit;
    }

    public void setMinit(String minit) {
        this.minit = minit;
    }

    // Getter y setter para lname
    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    // Getter y setter para jobId
    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    // Getter y setter para jobLvl
    public int getJobLvl() {
        return jobLvl;
    }

    public void setJobLvl(int jobLvl) {
        this.jobLvl = jobLvl;
    }

    // Getter y setter para pubId
    public int getPubId() {
        return pubId;
    }

    public void setPubId(int pubId) {
        this.pubId = pubId;
    }

    // Getter y setter para hireDate
    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    // Método para insertar un nuevo registro en la base de datos
    public void insertNames1() {
        String query = "INSERT INTO names1 (fname, minit, lname, job_id, job_lvl, pub_id, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.fname);
            statement.setString(2, this.minit);
            statement.setString(3, this.lname);
            statement.setInt(4, this.jobId);
            statement.setInt(5, this.jobLvl);
            statement.setInt(6, this.pubId);
            statement.setDate(7, new java.sql.Date(this.hireDate.getTime()));
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}