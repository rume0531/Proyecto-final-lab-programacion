import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class Job {
    private final int jobId;
    private final String jobDesc;
    private final int minLvl;
    private final int maxLvl;

    // Constructor
    public Job(int jobId, String jobDesc, int minLvl, int maxLvl) {
        this.jobId = jobId;
        this.jobDesc = jobDesc;
        this.minLvl = minLvl;
        this.maxLvl = maxLvl;
    }

    // Getters y setters para los atributos

    // Método para obtener un trabajo por ID
    public static Job getJobById(int jobId) {
        Job job = null;
        String query = "SELECT * FROM jobs WHERE job_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, jobId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    job = new Job(
                            resultSet.getInt("job_id"),
                            resultSet.getString("job_desc"),
                            resultSet.getInt("min_lvl"),
                            resultSet.getInt("max_lvl")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return job;
    }

    // Método para insertar un nuevo trabajo
    public void insertJob() {
        String query = "INSERT INTO jobs (job_desc, min_lvl, max_lvl) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.jobDesc);
            statement.setInt(2, this.minLvl);
            statement.setInt(3, this.maxLvl);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para actualizar un trabajo existente
    public void updateJob() {
        String query = "UPDATE jobs SET job_desc = ?, min_lvl = ?, max_lvl = ? WHERE job_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.jobDesc);
            statement.setInt(2, this.minLvl);
            statement.setInt(3, this.maxLvl);
            statement.setInt(4, this.jobId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para eliminar un trabajo existente
    public void deleteJob() {
        String query = "DELETE FROM jobs WHERE job_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, this.jobId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
