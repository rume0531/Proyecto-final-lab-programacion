import java.util.Scanner;

public class Store {
    private String storeId;
    private String storeName;
    private String storeAddress;
    private String city;
    private String state;
    private String zip;

    // Constructor para introducir datos por teclado
    public Store() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce el ID de la tienda: ");
        this.storeId = scanner.nextLine();

        System.out.print("Introduce el nombre de la tienda: ");
        this.storeName = scanner.nextLine();

        System.out.print("Introduce la dirección de la tienda: ");
        this.storeAddress = scanner.nextLine();

        System.out.print("Introduce la ciudad: ");
        this.city = scanner.nextLine();

        System.out.print("Introduce el estado: ");
        this.state = scanner.nextLine();

        System.out.print("Introduce el código postal: ");
        this.zip = scanner.nextLine();
    }




    // Getters y setters para storeId y storeName
    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    // Getters y setters para los campos opcionales
    public String getStoreAddress() {
        return storeAddress;
    }

    public void setStoreAddress(String storeAddress) {
        this.storeAddress = storeAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
}