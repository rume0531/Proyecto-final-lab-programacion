import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

public class Sales {
    private int saleId;
    private String storeId;
    private String titleId;
    private int quantity;
    private Date saleDate;

    // Constructor
    public Sales(int saleId, String storeId, String titleId, int quantity, Date saleDate) {
        this.saleId = saleId;
        this.storeId = storeId;
        this.titleId = titleId;
        this.quantity = quantity;
        this.saleDate = saleDate;
    }

    // Constructor para introducir datos por teclado
    public Sales() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce el ID de la venta: ");
        this.saleId = scanner.nextInt();

        System.out.print("Introduce el ID de la tienda: ");
        this.storeId = scanner.next();

        System.out.print("Introduce el ID del título: ");
        this.titleId = scanner.next();

        System.out.print("Introduce la cantidad vendida: ");
        this.quantity = scanner.nextInt();

        // Se puede utilizar un formato de fecha específico si se desea
        this.saleDate = new Date(); // Usando la fecha actual
    }

    // Getters y setters para saleId
    public int getSaleId() {
        return saleId;
    }

    public void setSaleId(int saleId) {
        this.saleId = saleId;
    }

    // Getters y setters para storeId
    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    // Getters y setters para titleId
    public String getTitleId() {
        return titleId;
    }

    public void setTitleId(String titleId) {
        this.titleId = titleId;
    }

    // Getters y setters para quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getters y setters para saleDate
    public Date getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(Date saleDate) {
        this.saleDate = saleDate;
    }

    // Método para insertar una nueva venta en la base de datos
    public void insertSales() {
        String query = "INSERT INTO sales (sale_id, store_id, title_id, quantity, sale_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, this.saleId);
            statement.setString(2, this.storeId);
            statement.setString(3, this.titleId);
            statement.setInt(4, this.quantity);
            statement.setDate(5, new java.sql.Date(this.saleDate.getTime()));
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
