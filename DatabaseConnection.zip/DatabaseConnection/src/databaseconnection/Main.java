package databaseconnection;

import java.util.Date;
import java.util.List;
import Names1.Names1; // Importar la clase Names1
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Ejemplo de uso de la clase Publisher
        try {
            // Ejemplo de uso de la clase Publisher
            Publisher publisher = new Publisher();
            publisher.insertPublisher(); // Insertar un nuevo editor en la base de datos
            // Ejemplo de uso de la clase Job
            Job job = new Job(1, "Descripción del trabajo", 1, 5);
            job.insertJob(); // Insertar un nuevo trabajo en la base de datos
            // Ejemplo de uso de la clase Store
            Store store = new Store();
            store.insertStore(); // Insertar una nueva tienda en la base de datos
            // Ejemplo de uso de la clase Title
            Title title = new Title("T001", "Título de ejemplo", "Tipo de ejemplo", 1, 19.99, 100.0, 10, 1000, "Notas de ejemplo", new Date());
            title.insertTitle(); // Insertar un nuevo título en la base de datos
            // Ejemplo de uso de la clase Sales
            Sales sales = new Sales();
            sales.insertSales(); // Insertar una nueva venta en la base de datos
            // Ejemplo de uso de la clase Names1
            Names1 names1 = new Names1("Nombre", "M", "Apellido", 1, 1, 1, new Date());
            names1.insertNames1(); // Insertar un nuevo registro en la base de datos
            // Obtener todos los títulos de la base de datos y mostrarlos
            List<Title> titles = Title.getAllTitles();
            for (Title t : titles) {
                System.out.println(t.getTitleId() + ": " + t.getTitle());
            }
            // Cerrar el scanner
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
