import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import databaseconnection.DatabaseConnection;






public class Title {
    private final String titleId;
    private final String title;
    private String type;
    private int pubId;
    private double price;
    private double advance;
    private int royalty;
    private int ytdSales;
    private String notes;
    private Date pubDate;

    // Constructor
    public Title(String titleId, String title, String type, int pubId, double price, double advance, int royalty, int ytdSales, String notes, Date pubDate) {
        this.titleId = titleId;
        this.title = title;
        this.type = type;
        this.pubId = pubId;
        this.price = price;
        this.advance = advance;
        this.royalty = royalty;
        this.ytdSales = ytdSales;
        this.notes = notes;
        this.pubDate = pubDate;
    }

    // Getter y setter para titleId (y otros atributos)

    // Método para obtener un título por ID
    public static Title getTitleById(String titleId) {
        Title title = null;
        String query = "SELECT * FROM titles WHERE title_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, titleId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    title = new Title(
                            resultSet.getString("title_id"),
                            resultSet.getString("title"),
                            resultSet.getString("typee"),
                            resultSet.getInt("pub_id"),
                            resultSet.getDouble("price"),
                            resultSet.getDouble("advance"),
                            resultSet.getInt("royalty"),
                            resultSet.getInt("ytd_sales"),
                            resultSet.getString("notes"),
                            resultSet.getDate("pubdate")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return title;
    }

    // Método para insertar un nuevo título
    public void insertTitle() {
        String query = "INSERT INTO titles (title_id, title, typee, pub_id, price, advance, royalty, ytd_sales, notes, pubdate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.titleId);
            statement.setString(2, this.title);
            statement.setString(3, this.type);
            statement.setInt(4, this.pubId);
            statement.setDouble(5, this.price);
            statement.setDouble(6, this.advance);
            statement.setInt(7, this.royalty);
            statement.setInt(8, this.ytdSales);
            statement.setString(9, this.notes);
            statement.setDate(10, new java.sql.Date(this.pubDate.getTime()));
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para actualizar un título existente
    public void updateTitle() {
        String query = "UPDATE titles SET title = ?, typee = ?, pub_id = ?, price = ?, advance = ?, royalty = ?, ytd_sales = ?, notes = ?, pubdate = ? WHERE title_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.title);
            statement.setString(2, this.type);
            statement.setInt(3, this.pubId);
            statement.setDouble(4, this.price);
            statement.setDouble(5, this.advance);
            statement.setInt(6, this.royalty);
            statement.setInt(7, this.ytdSales);
            statement.setString(8, this.notes);
            statement.setDate(9, new java.sql.Date(this.pubDate.getTime()));
            statement.setString(10, this.titleId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para eliminar un título existente
    public void deleteTitle() {
        String query = "DELETE FROM titles WHERE title_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.titleId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para obtener todos los títulos
    public static List<Title> getAllTitles() {
        List<Title> titles = new ArrayList<>();
        String query = "SELECT * FROM titles";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Title title = new Title(
                        resultSet.getString("title_id"),
                        resultSet.getString("title"),
                        resultSet.getString("typee"),
                        resultSet.getInt("pub_id"),
                        resultSet.getDouble("price"),
                        resultSet.getDouble("advance"),
                        resultSet.getInt("royalty"),
                        resultSet.getInt("ytd_sales"),
                        resultSet.getString("notes"),
                        resultSet.getDate("pubdate")
                );
                titles.add(title);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return titles;
    }
}