import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Publisher {
    private String pubId;
    private String pubName;
    private String city;
    private String state;
    private String country;

    // Constructor
    public Publisher(String pubId, String pubName, String city, String state, String country) {
        this.pubId = pubId;
        this.pubName = pubName;
        this.city = city;
        this.state = state;
        this.country = country;
    }

    // Constructor para introducir datos por teclado
    public Publisher() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce el ID del editor: ");
        this.pubId = scanner.nextLine();

        System.out.print("Introduce el nombre del editor: ");
        this.pubName = scanner.nextLine();

        System.out.print("Introduce la ciudad del editor: ");
        this.city = scanner.nextLine();

        System.out.print("Introduce el estado del editor: ");
        this.state = scanner.nextLine();

        System.out.print("Introduce el país del editor: ");
        this.country = scanner.nextLine();
    }

    // Getter para pubId
    public String getPubId() {
        return pubId;
    }

    // Setter para pubId
    public void setPubId(String pubId) {
        this.pubId = pubId;
    }

    // Getter para pubName
    public String getPubName() {
        return pubName;
    }

    // Setter para pubName
    public void setPubName(String pubName) {
        this.pubName = pubName;
    }

    // Getter para city
    public String getCity() {
        return city;
    }

    // Setter para city
    public void setCity(String city) {
        this.city = city;
    }

    // Getter para state
    public String getState() {
        return state;
    }

    // Setter para state
    public void setState(String state) {
        this.state = state;
    }

    // Getter para country
    public String getCountry() {
        return country;
    }

    // Setter para country
    public void setCountry(String country) {
        this.country = country;
    }

    // Método para insertar un nuevo editor en la base de datos
    public void insertPublisher() {
        String query = "INSERT INTO publishers (pub_id, pub_name, city, state, country) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.pubId);
            statement.setString(2, this.pubName);
            statement.setString(3, this.city);
            statement.setString(4, this.state);
            statement.setString(5, this.country);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para actualizar un editor existente en la base de datos
    public void updatePublisher() {
        String query = "UPDATE publishers SET pub_name = ?, city = ?, state = ?, country = ? WHERE pub_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.pubName);
            statement.setString(2, this.city);
            statement.setString(3, this.state);
            statement.setString(4, this.country);
            statement.setString(5, this.pubId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para eliminar un editor existente de la base de datos
    public void deletePublisher() {
        String query = "DELETE FROM publishers WHERE pub_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, this.pubId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
